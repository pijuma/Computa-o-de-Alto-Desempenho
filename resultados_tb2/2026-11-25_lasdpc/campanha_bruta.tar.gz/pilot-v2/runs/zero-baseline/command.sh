/home/ssc903-tb-g01/tb2-campaign.8Kvjsa/pilot-v2/source/fire_seq /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/pilot-v2/inputs/zero.txt 
