/home/ssc903-tb-g01/tb2-campaign.8Kvjsa/sizing/source/fire_seq /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/sizing/inputs/zero.txt 
