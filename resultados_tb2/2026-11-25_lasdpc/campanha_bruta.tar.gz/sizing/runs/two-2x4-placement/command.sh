mpirun --hostfile /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/sizing/hosts/two-2x4 --map-by ppr:1:node:PE=4 --bind-to core --report-bindings -np 2 hostname 
