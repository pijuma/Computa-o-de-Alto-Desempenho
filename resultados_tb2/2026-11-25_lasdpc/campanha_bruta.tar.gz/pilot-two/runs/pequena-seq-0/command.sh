/home/ssc903-tb-g01/tb2-campaign.8Kvjsa/pilot-two/source/fire_seq /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/pilot-two/inputs/pequena-seq.txt 
