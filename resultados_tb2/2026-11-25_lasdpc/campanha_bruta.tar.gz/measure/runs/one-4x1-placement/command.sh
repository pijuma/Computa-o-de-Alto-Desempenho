mpirun --hostfile /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/measure/hosts/one-4x1 --map-by ppr:4:node:PE=1 --bind-to core --report-bindings -np 4 hostname 
