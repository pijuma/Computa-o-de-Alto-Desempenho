/home/ssc903-tb-g01/tb2-campaign.8Kvjsa/measure/source/fire_seq /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/measure/inputs/pequena-seq.txt 
