mpirun --hostfile /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/measure/hosts/one-1x2 --map-by ppr:1:node:PE=2 --bind-to core --report-bindings -np 1 hostname 
