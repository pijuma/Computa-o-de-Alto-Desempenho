mpirun --hostfile /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/measure/hosts/one-2x2 --map-by ppr:2:node:PE=2 --bind-to core --report-bindings -np 2 hostname 
