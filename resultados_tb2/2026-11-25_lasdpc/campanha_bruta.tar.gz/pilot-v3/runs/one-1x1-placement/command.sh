mpirun --hostfile /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/pilot-v3/hosts/one-1x1 --map-by ppr:1:node:PE=1 --bind-to core --report-bindings -np 1 hostname 
