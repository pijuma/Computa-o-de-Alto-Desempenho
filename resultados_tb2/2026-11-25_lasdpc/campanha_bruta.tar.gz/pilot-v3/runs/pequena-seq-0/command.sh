/home/ssc903-tb-g01/tb2-campaign.8Kvjsa/pilot-v3/source/fire_seq /home/ssc903-tb-g01/tb2-campaign.8Kvjsa/pilot-v3/inputs/pequena-seq.txt 
