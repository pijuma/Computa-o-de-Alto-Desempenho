suppressPackageStartupMessages({library(ggplot2)})

args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 2) stop('uso: Rscript gerar_figuras_o3.R resumo.csv saida')
csv <- args[[1]]
out <- args[[2]]
dir.create(out, recursive=TRUE, showWarnings=FALSE)

d <- read.csv(csv, check.names=FALSE)
d$carga <- factor(d$carga, levels=c('pequena','media','grande'), labels=c('Pequena','Média','Grande'))
cores <- c('Pequena'='#2563A6','Média'='#16857A','Grande'='#D2643E')
tema <- theme_minimal(base_size=10) + theme(
  panel.grid.minor=element_blank(), panel.grid.major.x=element_blank(),
  legend.position='top', legend.title=element_blank(),
  strip.text=element_text(face='bold'), plot.title=element_text(face='bold'),
  plot.subtitle=element_text(colour='#4B5563'), plot.margin=margin(7,9,7,7))

principal <- subset(d, (versao=='fire_seq' & threads==1) |
  (versao=='fire_omp' & schedule=='static' & threads %in% c(1,2,4,8,16)))
omp <- subset(principal, versao=='fire_omp')
seq <- subset(principal, versao=='fire_seq')

p1 <- ggplot(omp, aes(threads, media_s, colour=carga, group=carga)) +
  geom_ribbon(aes(ymin=media_s-ic95_media_s, ymax=media_s+ic95_media_s, fill=carga),
              alpha=.14, colour=NA) +
  geom_line(linewidth=.8) + geom_point(size=2.1) +
  geom_hline(data=seq, aes(yintercept=media_s), inherit.aes=FALSE,
             linetype='dashed', colour='#5F6368', linewidth=.5) +
  facet_wrap(~carga, scales='free_y', nrow=1) +
  scale_x_continuous(trans='log2', breaks=c(1,2,4,8,16)) +
  scale_colour_manual(values=cores) + scale_fill_manual(values=cores) +
  labs(x='Número de threads', y='Tempo médio (s)') + tema + theme(legend.position='none')
ggsave(file.path(out,'01_tempo_o3.pdf'),p1,width=10.1,height=3.55,device=cairo_pdf)
ggsave(file.path(out,'01_tempo_o3.png'),p1,width=10.1,height=3.55,dpi=220,bg='white')

esc <- rbind(
  data.frame(carga=omp$carga,threads=omp$threads,metrica='Speedup',valor=omp$speedup),
  data.frame(carga=omp$carga,threads=omp$threads,metrica='Eficiência (%)',valor=100*omp$eficiencia))
esc$metrica <- factor(esc$metrica,levels=c('Speedup','Eficiência (%)'))
p2 <- ggplot(esc, aes(threads,valor,colour=carga,group=carga)) +
  geom_line(linewidth=.8) + geom_point(size=2.1) +
  geom_vline(xintercept=c(4,8),linetype='dotted',colour='#777777',linewidth=.45) +
  facet_wrap(~metrica,scales='free_y',nrow=1) +
  scale_x_continuous(trans='log2', breaks=c(1,2,4,8,16)) + scale_colour_manual(values=cores) +
  labs(x='Número de threads',y=NULL) + tema
ggsave(file.path(out,'02_speedup_eficiencia_o3.pdf'),p2,width=10.1,height=3.75,device=cairo_pdf)
ggsave(file.path(out,'02_speedup_eficiencia_o3.png'),p2,width=10.1,height=3.75,dpi=220,bg='white')

s <- subset(d,carga=='Média' & versao=='fire_omp' & threads==4)
ordem <- c('guided,16','static','dynamic,64','static,16','dynamic,16')
s$schedule <- factor(s$schedule,levels=rev(ordem))
p3 <- ggplot(s,aes(media_s,schedule)) +
  geom_errorbar(aes(xmin=media_s-ic95_media_s,xmax=media_s+ic95_media_s),
                orientation='y',width=.22,linewidth=.55,colour='#2563A6') +
  geom_point(size=2.4,colour='#2563A6') +
  labs(x='Tempo médio com -O3 (s)',y=NULL) +
  tema + theme(legend.position='none',panel.grid.major.y=element_blank())
ggsave(file.path(out,'03_schedules_o3.pdf'),p3,width=7.3,height=3.8,device=cairo_pdf)
ggsave(file.path(out,'03_schedules_o3.png'),p3,width=7.3,height=3.8,dpi=220,bg='white')
