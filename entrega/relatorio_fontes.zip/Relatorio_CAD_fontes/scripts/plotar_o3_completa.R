suppressPackageStartupMessages({library(ggplot2)})

# Fator de desempenho -O2/-O3 por numero de threads, a partir do resumo do cluster.
# uso: Rscript plotar_o3_completa.R comparacao_o2_o3.csv saida
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 2) stop('uso: Rscript plotar_o3_completa.R comparacao_o2_o3.csv saida')
csv <- args[[1]]
out <- args[[2]]
dir.create(out, recursive=TRUE, showWarnings=FALSE)

d <- read.csv(csv, check.names=FALSE)
d <- subset(d, versao=='fire_omp' & schedule=='static' & threads %in% c(1,2,4,8,16))
d$carga <- factor(d$carga, levels=c('pequena','media','grande'),
                  labels=c('Pequena','Média','Grande'))
cores <- c('Pequena'='#2563A6','Média'='#16857A','Grande'='#D2643E')
tema <- theme_minimal(base_size=10) + theme(
  panel.grid.minor=element_blank(), panel.grid.major.x=element_blank(),
  legend.position='top', legend.title=element_blank(), plot.margin=margin(7,9,7,7))

p <- ggplot(d, aes(threads, fator_o2_sobre_o3, colour=carga, group=carga)) +
  geom_hline(yintercept=1, linetype='dashed', colour='#5F6368', linewidth=.45) +
  geom_errorbar(aes(ymin=fator_ic95_low, ymax=fator_ic95_high), width=.35, linewidth=.5) +
  geom_line(linewidth=.8) + geom_point(size=2.1) +
  scale_x_continuous(trans='log2', breaks=c(1,2,4,8,16)) + scale_colour_manual(values=cores) +
  labs(x='Número de threads', y=expression('Fator de desempenho '*t[O2]/t[O3])) + tema

ggsave(file.path(out,'04_fator_o2_o3.pdf'), p, width=7.6, height=4.0, device=cairo_pdf)
ggsave(file.path(out,'04_fator_o2_o3.png'), p, width=7.6, height=4.0, dpi=220, bg='white')
cat('Figura 04 gerada em', out, '\n')
