# Fracao serial determinada experimentalmente (metrica de Karp-Flatt):
#   e(T) = (1/S(T) - 1/T) / (1 - 1/T),  T >= 2
# a partir dos speedups medidos no cluster. Nao usa dado novo.
# Reproduz os valores da Tabela 7 do relatorio e grava um CSV auditavel.
# uso: Rscript karp_flatt.R resumo_o3_final.csv saida_csv
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 2) stop('uso: Rscript karp_flatt.R resumo_o3_final.csv saida_csv')
csv <- args[[1]]; out_csv <- args[[2]]

d <- read.csv(csv, check.names=FALSE)
d <- subset(d, versao=='fire_omp' & schedule=='static' & threads %in% c(2,4,8,16))
d$e <- (1/d$speedup - 1/d$threads) / (1 - 1/d$threads)

tab <- d[order(d$carga, d$threads), c('carga','threads','speedup','e')]
tab$e_pct <- round(100*tab$e, 1)
write.csv(tab, out_csv, row.names=FALSE)

cat('carga  threads  speedup   e(%)\n')
for (i in seq_len(nrow(tab)))
  cat(sprintf('%-7s %4d  %7.3f  %5.1f\n', tab$carga[i], tab$threads[i], tab$speedup[i], tab$e_pct[i]))
