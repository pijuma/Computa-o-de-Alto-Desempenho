from pathlib import Path
from html import escape
import subprocess

ROOT = Path(__file__).resolve().parent
OUT_DIR = ROOT / "images"
OUT_DIR.mkdir(parents=True, exist_ok=True)
SVG = OUT_DIR / "diagrama_solucao.svg"
PDF = OUT_DIR / "diagrama_solucao.pdf"
PNG = OUT_DIR / "diagrama_solucao.png"

W, H = 1900, 1030

INK = "#102A43"
MUTED = "#526577"
LINE = "#B8C6D1"
SOFT = "#F5F8FA"
TIMED = "#F3F8FC"
LOOP = "#FFFFFF"
FOR = "#2F6B9A"
SIMD = "#147D73"
SINGLE = "#B56A16"
SERIAL = "#334E68"

parts: list[str] = []


def add(x: str) -> None:
    parts.append(x)


def text(x, y, value, size=26, weight=400, fill=INK, anchor="start", cls=""):
    add(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" '
        f'fill="{fill}" text-anchor="{anchor}" class="{cls}">{escape(value)}</text>')


def multiline(x, y, lines, size=24, fill=INK, anchor="middle", gap=1.24, weight=400):
    add(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">')
    for i, line in enumerate(lines):
        dy = 0 if i == 0 else size * gap
        add(f'<tspan x="{x}" dy="{dy}">{escape(line)}</tspan>')
    add('</text>')


def rounded(x, y, w, h, fill, stroke=LINE, sw=2, r=18, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" '
        f'stroke="{stroke}" stroke-width="{sw}"{d}/>')


def arrow(x1, y1, x2, y2, stroke=INK, sw=3, marker="arrow", dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    add(f'<path d="M {x1} {y1} L {x2} {y2}" fill="none" stroke="{stroke}" '
        f'stroke-width="{sw}" marker-end="url(#{marker})"{d}/>')


def card(x, y, w, h, number, title_value, directive_lines, color):
    rounded(x, y, w, h, "#FFFFFF", stroke="#CCD7DF", sw=2, r=16)
    add(f'<rect x="{x}" y="{y}" width="{w}" height="8" rx="4" fill="{color}"/>')
    add(f'<circle cx="{x+30}" cy="{y+37}" r="17" fill="{color}"/>')
    text(x+30, y+45, str(number), size=22, weight=600, fill="#FFFFFF", anchor="middle")
    text(x+57, y+45, title_value, size=26, weight=600, fill=INK)
    multiline(x+w/2, y+88, directive_lines, size=22, fill=MUTED, gap=1.30)


add(f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">
<title>Fluxo exato da versão OpenMP da simulação de incêndio</title>
<desc>Preparação serial fora do cronômetro, núcleo cronometrado com uma região paralela persistente, cinco fases por passo separadas por barreiras implícitas, contagem final ainda dentro da equipe e pós-processamento serial.</desc>
<defs>
  <marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth">
    <path d="M0,0 L0,6 L9,3 z" fill="context-stroke"/>
  </marker>
  <marker id="arrow-small" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto" markerUnits="strokeWidth">
    <path d="M0,0 L0,6 L8,3 z" fill="context-stroke"/>
  </marker>
  <style>
    text {{ font-family: Inter, "Helvetica Neue", Arial, sans-serif; }}
  </style>
</defs>
<rect width="1900" height="1030" fill="#FFFFFF"/>
''')

# Phase labels
text(70, 58, "PREPARAÇÃO SERIAL", size=23, weight=600, fill=MUTED)
add(f'<line x1="70" y1="76" x2="300" y2="76" stroke="{LINE}" stroke-width="2"/>')
text(360, 58, "NÚCLEO CRONOMETRADO", size=23, weight=600, fill=SIMD)
add(f'<line x1="360" y1="76" x2="1520" y2="76" stroke="{SIMD}" stroke-width="5"/>')
text(1830, 58, "PÓS-PROCESSAMENTO SERIAL", size=23, weight=600, fill=MUTED, anchor="end")
add(f'<line x1="1570" y1="76" x2="1830" y2="76" stroke="{LINE}" stroke-width="2"/>')

# Preparation lane
rounded(60, 130, 250, 710, SOFT, stroke="#D6E0E7", sw=2, r=22)
text(185, 178, "Fora do cronômetro", size=22, weight=600, fill=SERIAL, anchor="middle")
rounded(88, 235, 194, 300, "#FFFFFF", stroke="#BCC9D3", sw=2, r=16)
add(f'<rect x="88" y="235" width="194" height="9" rx="4" fill="{SERIAL}"/>')
text(185, 290, "Preparar", size=29, weight=600, fill=INK, anchor="middle")
multiline(185, 342, ["ler + validar entrada", "alocar vetores", "gerar floresta", "aplicar focos / zonas", "configurar runtime OpenMP"], size=19, fill=MUTED, gap=1.36)
rounded(88, 595, 194, 122, "#EAF0F4", stroke="none", sw=0, r=14)
text(185, 635, "Estado inicial", size=23, weight=600, fill=SERIAL, anchor="middle")
multiline(185, 672, ["determinístico", "e idêntico ao sequencial"], size=20, fill=MUTED, gap=1.3)

# Timed persistent region
rounded(350, 105, 1170, 790, TIMED, stroke="#7FA7C2", sw=2.5, r=24)
text(385, 150, "Timer envolve uma região paralela persistente", size=29, weight=650, fill=INK)
text(1485, 150, "T threads  ·  default(none)", size=22, weight=500, fill=MUTED, anchor="end")
add(f'<circle cx="370" cy="184" r="6" fill="{SIMD}"/>')
text(388, 192, "omp_get_wtime(): início  ·  zerar os cinco acumuladores finais", size=20, weight=500, fill=SIMD)
text(1485, 192, "todos os omp for: schedule(runtime)", size=18, weight=500, fill=MUTED, anchor="end")

# Per-step loop
rounded(390, 220, 1090, 465, LOOP, stroke="#A9BBC8", sw=2, r=20, dash="8 7")
text(425, 260, "DENTRO DA EQUIPE · PARA CADA PASSO  p", size=22, weight=650, fill=MUTED)
text(1445, 260, "enquanto p < P e há células em chamas", size=20, weight=500, fill=MUTED, anchor="end")

xs = [420, 630, 840, 1050, 1260]
ws = [170, 170, 170, 170, 180]
card(xs[0], 305, ws[0], 220, 1, "Ativar", ["omp for", "collapse(2)", "ativa contenções"], FOR)
card(xs[1], 305, ws[1], 220, 2, "Atualizar", ["omp for", "collapse(2)", "próximo estado"], FOR)
card(xs[2], 305, ws[2], 220, 3, "Zerar", ["single", "novas = 0", "chamas = 0"], SINGLE)
card(xs[3], 305, ws[3], 220, 4, "Reduzir", ["omp for simd", "reduction(+)", "ignições / chamas"], SIMD)
card(xs[4], 305, ws[4], 220, 5, "Concluir", ["single", "pico + total", "troca buffers", "passo++"], SINGLE)

# Explicit barrier separators
for left, right in zip([590, 800, 1010, 1220], [630, 840, 1050, 1260]):
    cx = (left + right) / 2
    add(f'<line x1="{cx}" y1="325" x2="{cx}" y2="505" stroke="{LINE}" stroke-width="2" stroke-dasharray="5 6"/>')
    add(f'<path d="M {cx-8} 415 L {cx} 407 L {cx+8} 415 L {cx} 423 Z" fill="#FFFFFF" stroke="{MUTED}" stroke-width="2"/>')
    text(cx, 552, "barreira", size=17, weight=500, fill=MUTED, anchor="middle")
    text(cx, 574, "implícita", size=17, weight=500, fill=MUTED, anchor="middle")

# The implicit barrier at the end of the final single precedes the loop test.
add(f'<line x1="1460" y1="325" x2="1460" y2="505" stroke="{LINE}" stroke-width="2" stroke-dasharray="5 6"/>')
add(f'<path d="M 1452 415 L 1460 407 L 1468 415 L 1460 423 Z" fill="#FFFFFF" stroke="{MUTED}" stroke-width="2"/>')

# Forward flow and loop back
for a, b in zip(xs[:-1], xs[1:]):
    arrow(a + ws[xs.index(a)] + 6, 415, b - 8, 415, stroke="#7D93A3", sw=2.4, marker="arrow-small")
add(f'<path d="M 1350 548 C 1335 635, 570 635, 505 548" fill="none" stroke="{FOR}" stroke-width="3" marker-end="url(#arrow)"/>')
rounded(765, 590, 350, 48, "#EFF5FA", stroke="none", sw=0, r=18)
text(940, 621, "próximo passo", size=22, weight=600, fill=FOR, anchor="middle")

# Shared buffers and final count, both still timed and inside persistent team
rounded(420, 725, 500, 118, "#EAF1F6", stroke="#C4D3DD", sw=1.5, r=16)
text(445, 762, "Buffers compartilhados", size=22, weight=650, fill=INK)
multiline(670, 793, ["estado_atual / tempo_atual  →  próximo_estado / próximo_tempo", "troca de ponteiros no passo 5"], size=20, fill=MUTED, gap=1.35)

rounded(1000, 715, 440, 138, "#FFFFFF", stroke="#86B5AE", sw=2, r=16)
add(f'<rect x="1000" y="715" width="440" height="9" rx="4" fill="{SIMD}"/>')
text(1030, 765, "Ainda na mesma equipe", size=22, weight=600, fill=MUTED)
text(1030, 805, "Contar os cinco estados finais", size=25, weight=650, fill=INK)
text(1030, 837, "omp for simd · reduction(5) · barreira final", size=20, weight=500, fill=SIMD)
arrow(1350, 548, 1240, 705, stroke=SIMD, sw=3)
text(1395, 647, "encerra", size=18, weight=500, fill=SIMD, anchor="middle")
text(1395, 670, "o laço", size=18, weight=500, fill=SIMD, anchor="middle")

text(1485, 877, "sair da equipe  →  montar Estatisticas  →  omp_get_wtime(): fim", size=19, weight=500, fill=SIMD, anchor="end")

# Post-processing lane
rounded(1560, 130, 280, 710, SOFT, stroke="#D6E0E7", sw=2, r=22)
text(1700, 178, "Fora do cronômetro", size=22, weight=600, fill=SERIAL, anchor="middle")
rounded(1590, 285, 220, 300, "#FFFFFF", stroke="#BCC9D3", sw=2, r=16)
add(f'<rect x="1590" y="285" width="220" height="9" rx="4" fill="{SERIAL}"/>')
text(1700, 340, "Finalizar", size=29, weight=600, fill=INK, anchor="middle")
multiline(1700, 400, ["checksum sequencial", "percentuais", "impressão das métricas", "liberação da memória"], size=22, fill=MUTED, gap=1.42)

# Main transitions and timer boundary
arrow(310, 485, 345, 485, stroke=INK, sw=3.5)
arrow(1445, 784, 1555, 485, stroke=INK, sw=3.5)

# Legend: semantic use of color
text(70, 955, "CONSTRUÇÕES", size=19, weight=650, fill=MUTED)
add(f'<line x1="250" y1="949" x2="305" y2="949" stroke="{FOR}" stroke-width="8" stroke-linecap="round"/>')
text(320, 957, "omp for", size=20, weight=500, fill=INK)
add(f'<line x1="455" y1="949" x2="510" y2="949" stroke="{SIMD}" stroke-width="8" stroke-linecap="round"/>')
text(525, 957, "omp for simd + redução", size=20, weight=500, fill=INK)
add(f'<line x1="785" y1="949" x2="840" y2="949" stroke="{SINGLE}" stroke-width="8" stroke-linecap="round"/>')
text(855, 957, "single", size=20, weight=500, fill=INK)
add(f'<line x1="995" y1="949" x2="1050" y2="949" stroke="{LINE}" stroke-width="3" stroke-dasharray="6 6"/>')
text(1065, 957, "barreira implícita", size=20, weight=500, fill=INK)
text(1830, 957, "ordem real do fire_omp.c", size=19, weight=500, fill=MUTED, anchor="end")

add('</svg>')
SVG.write_text("\n".join(parts), encoding="utf-8")
tmp_pdf = OUT_DIR / "diagrama_solucao_pdf17.tmp.pdf"
subprocess.run(["rsvg-convert", "-f", "pdf", "-o", str(tmp_pdf), str(SVG)], check=True)
subprocess.run([
    "gs", "-q", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.5",
    "-dPDFSETTINGS=/prepress", "-dNOPAUSE", "-dBATCH",
    f"-sOutputFile={PDF}", str(tmp_pdf),
], check=True)
tmp_pdf.unlink()
subprocess.run([
    "rsvg-convert", "-f", "png", "-w", str(W), "-h", str(H),
    "-o", str(PNG), str(SVG),
], check=True)
print(SVG)
print(PDF)
print(PNG)
