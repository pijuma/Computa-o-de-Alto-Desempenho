# Fontes do relatório CAD

Pacote da versão final do relatório do TB1, consolidada em 22/09/2026.

## Conteúdo

- `relatorio.tex`: fonte LaTeX;
- `relatorio.pdf`: PDF final verificado;
- `images/`: diagrama e figuras usadas pelo relatório, além das versões PNG/SVG disponíveis;
- `dados/`: resumos CSV preservados das campanhas `-O2`, `-O3` e do experimento SIMD;
- `scripts/`: geração das figuras finais e do diagrama.

## Compilação

Na raiz desta pasta:

```bash
xelatex -interaction=nonstopmode -halt-on-error relatorio.tex
xelatex -interaction=nonstopmode -halt-on-error relatorio.tex
```

A segunda passagem atualiza sumário e referências internas. O relatório final usa XeLaTeX e as figuras PDF já incluídas.

## Proveniência principal

- nó: `hal01`;
- compilador da campanha: GCC 5.3.1;
- flags: `-Wall -Wextra -O3 -fopenmp`;
- campanha: `20260921T002355Z_ba863a76feec_o3`;
- SHA-256 de `fire_omp.c`: `ba863a76feecfb13734f853babb769e1afbce002d946d8a5eb19620e8ab3a04a`;
- SHA-256 do PDF incluído: `b9a373cea16e42afc1f363e3db2e9fb959d755cbba865071e5a173e34faa570c`.
